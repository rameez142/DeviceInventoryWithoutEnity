﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PatrolWebApp
{
    class Handler_Global
    {

       // public static string connectString = "Data Source=" + "" + ";Initial Catalog=" + "" + ";Persist Security Info=True;User ID=" + "" + "" + ";Password=" + "";
        public static string connectString =  ConfigurationManager.ConnectionStrings["PatrolsConnectionString"].ToString();

    }
}
